const express = require('express');
const router =  express.Router();

module.exports = (db) => {
    router.get('/read', (req, res) =>{

        const sql = 'SELECT * FROM Categorias';
        
        db.query(sql,(err, result) =>{
            if (err) {
                console.error('Error al leer registros:', err);
                res.status(500).json({ error: 'Error al leer registros'});
            }   else {
                res.status(200).json(result);
            }
        });

    });

    router.post('/create', (req, res) => {
      // Recibe los datos del nuevo registro desde el cuerpo de la solicitud (req.body)
      const { Nombre_Categoria } = req.body;
  
      // Verifica si se proporcionaron los datos necesarios
      if (!Nombre_Categoria ) {
        return res.status(400).json({ error: 'Todos los campos son obligatorios' });
      }
  
      // Realiza la consulta SQL para insertar un nuevo registro con ID específico
      const sql = `INSERT INTO Categorias (Nombre_Categoria) VALUES (?)`;
      const values = [Nombre_Categoria];
  
      // Ejecuta la consulta
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error('Error al insertar registro:', err);
          res.status(500).json({ error: 'Error al insertar registro' });
        } else {
          // Devuelve el ID del nuevo registro como respuesta
          res.status(201).json({ Id_Categoria });
        }
      });
    });

    

    router.put('/update/:id', (req, res) => {
      // Obtén el ID del registro a actualizar desde los parámetros de la URL
      const id = req.params.id;
  
      // Recibe los datos actualizados desde el cuerpo de la solicitud (req.body)
      const { Nombre_Categoria } = req.body;
  
      // Verifica si se proporcionaron los datos necesarios
      if (!Nombre_Categoria) {
        return res.status(400).json({ error: 'Todos los campos son obligatorios' });
      }
  
      // Realiza la consulta SQL para actualizar el registro por ID
      const sql = `
        UPDATE Categorias
        SET Nombre_Categoria = ?
        WHERE Id_Categoria = ?
      `;
  
      const values = [Nombre_Categoria, Id_Categoria];
  
      // Ejecuta la consulta
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error('Error al actualizar el registro:', err);
          res.status(500).json({ error: 'Error al actualizar el registro' });
        } else {
          // Devuelve un mensaje de éxito
          res.status(200).json({ message: 'Registro actualizado con éxito' });
        }
      });
    });

    
    router.delete('/delete/:id', (req, res) => {
      // Obtén el ID del registro a eliminar desde los parámetros de la URL
      const id = req.params.id;
  
      // Realiza la consulta SQL para eliminar el registro por ID
      const sql = 'DELETE FROM Categorias WHERE Id_Categoria = ?';
  
      // Ejecuta la consulta
      db.query(sql, [id], (err, result) => {
        if (err) {
          console.error('Error al eliminar el registro:', err);
          res.status(500).json({ error: 'Error al eliminar el registro' });
        } else {
          // Devuelve un mensaje de éxito
          res.status(200).json({ message: 'Registro eliminado con éxito' });
        }
      });
    });

   
    return router;
};

